﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    public class Propietario : Persona
    {
        public Propietario()
        {
            
        }
        public Propietario( int id, string nombre, string telefono)
        {
            Id = id;
            Nombre = nombre;
            Telefono = telefono;
        }

        public override string Formatear()
        {
            return $"{Id};{Nombre};{Telefono}";
        }
    }
}
